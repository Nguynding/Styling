import React from 'react';
import { View, StyleSheet, Text } from 'react-native';

const Square = ({ color, children }) => (
  <View style={[styles.square, { backgroundColor: color }]}>
    <Text style={styles.text}>{children}</Text>
  </View> )

export default function App() {
  return (
    <View style={styles.container}>
        <Square color="#6950e6">System 1</Square>
        <Square color="#f2b8da">System 2</Square>
        <Square color="#6e9cd4">System 3</Square>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    
  },
  square: {
    width: 100,
    height: 100,
    margin: 10,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 30
  },
  text: {
    color: 'white',
  }
});
